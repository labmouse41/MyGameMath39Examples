
#include "Precompiled.h"
using namespace CK;

const Color32 Color32::Error(255, 0, 255, 255);
