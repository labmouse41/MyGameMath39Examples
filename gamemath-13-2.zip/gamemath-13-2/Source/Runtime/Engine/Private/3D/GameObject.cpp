
#include "Precompiled.h"
using namespace CK::DDD;

GameObject GameObject::Invalid(Math::InvalidHashName);
