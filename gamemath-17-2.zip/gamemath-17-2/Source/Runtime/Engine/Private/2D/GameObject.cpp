
#include "Precompiled.h"
using namespace CK::DD;

GameObject GameObject::Invalid(Math::InvalidHashName);
